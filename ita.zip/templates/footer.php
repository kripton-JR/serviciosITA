 <!--Footer-->
<script src="js\bootstrap.min.js"></script>

 <div class="container">
        <footer class="py-3 my-4">
            <ul class="nav justify-content-center border-bottom pb-3 mb-3">
                <li class="nav-item">
                    <a class="nav-link active px-2 text-muted" aria-current="page" href="#">Inicio</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active px-2 text-muted" href="#">Servicios</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active px-2 text-muted" href="#">Informacion</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active px-2 text-muted" href="#">Panel de control</a>
                </li>

            </ul>
            <p class="text-center text-muted">&copy; 2022 Instituto Tecnologico de Altamira, Inc</p>
        </footer>
    </div>

    </body>

</html>