<?php
$banera = false;
if(isset($_GET['bandera'])){
$banera = $_GET['bandera'];
}else{
}
?>

<?php 
include './templates/navbar.php';
?>

    <!--Formulario de la solicitud-->
    <div class="solicitud container mt-5 justify-content-center">

        <h2 class="text-center">
            PROCESO DE BAJA ACADEMICA
        </h2>
        <?php 
        if ($banera == true) {
            echo '<div class="alert alert-danger" role="alert">
       Ingresa informacion valida
      </div>';
        }
        ?>

        <form action="procesos\baja.php" method="post">
            <div class="row">
                <div class="col-sm-12 col-md-6">
                    <div class="row">
                        <div>
                            <label for="tipobaja" class="form-label">Tipo de baja</label>
                            <select class="form-select" aria-label="Default select example" name="tipobaja">
                                <option selected>Seleccione el tipo de baja academica</option>
                                <option value="1">Temporal</option>
                                <option value="2">Definitiva</option>
                            </select>
                        </div>

                        <div>
                            <label for="motivobaja" class="form-label">Motivo de baja</label>
                            <select class="form-select" aria-label="Default select example" name="motivobaja">
                                <option selected>Seleccione el tipo de baja academica</option>
                                <option value="1">Académicos</option>
                                <option value="2">Personales</option>
                                <option value="3">Otros</option>
                            </select>
                        </div>

                        <div>
                            <label for="motivo" class="form-label">Describa el motivo de su baja</label><br>
                            <textarea rows="5" name="motivo" class="form-control" onKeyUp="maximo(this,372);" onKeyDown="maximo(this,372);"
                                placeholder="Estoy en un problema economico y nesesito un tiempo para dedicar al trabajo"></textarea>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-12 col-md-4">
                            <label for="semestre" class="form-label">Semestre</label>
                            <select class="form-select" aria-label="Default select example" name="semestre">
                                <option selected>Seleccione</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                                <option value="9">9</option>
                                <option value="10">10</option>
                                <option value="11">11</option>
                                <option value="12">12</option>
                            </select>
                        </div>
                        <div class="col-sm-12 col-md-4">
                            <label for="grupo" class="form-label">Grupo</label>
                            <select class="form-select" aria-label="Default select example" name="grupo">
                                <option selected>Grupo</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        </div>
                        <div class="col-sm-12 col-md-4">
                            <label for="" class="form-label">Numero de control</label>
                            <input type="number" class="form-control" name="numerocontrol" id="">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-12 col-md-12">
                            <label for="carrera" class="form-label">Carrera</label>
                            <select class="form-select" aria-label="Default select example" name="carrera">
                                <option selected>Carrera</option>
                                <option value="Ingenieria en sistemas computacionales">Ingenieria en sistemas
                                    computacionales</option>
                                <option value="Ingenieria en logistica">Ingenieria en logistica</option>
                                <option value="Ingenieria en agronomia">Ingenieria en agronomia</option>
                                <option value="Lic. Biologia">Lic. Biologia</option>
                                <option value="Lic. Administracion de empresas">Lic. Administracion de empresas</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12 col-md-12">
                            <label for="nombre" class="form-label">Nombre completo</label>
                            <input type="text" name="nombre" id="" class="form-control">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-12 col-md-12 d-grid d-gap-2">
                            <input type="submit" value="Solicitar PDF" class="btn btn-primary">
                        </div>
                    </div>

                </div>

                <div class="col-sm-12 col-md-6">
                    <img src="imagenes\imagenesSVG\Startup_Flatline.svg" alt="Estudiantes desarrollando un sistema"
                        class="img-fluid">
                </div>

            </div>
      </form>
    </div>
    <script src="js\camposmaximo.js"></script>

    <?php 
    include './templates/footer.php';
    ?> 
   
