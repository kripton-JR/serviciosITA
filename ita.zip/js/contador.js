const mensaje = document.getElementById('solicito');
const contador = document.getElementById('contador');

mensaje.addEventListener('input', function(e) {
    const target = e.target;
    const longitudMax = 210;
    const longitudAct = target.value.length;
    contador.innerHTML = `${longitudAct}/${longitudMax}`;
    var mens = document.getElementById('solicito').value;

    if(mens.length > 104){
         contador.className = 'alert alert-danger';

         if(mens.charAt(104) == " "){
            contador.className = 'alert alert-success';
         }
         else{
            contador.innerHTML = `${longitudAct}/${longitudMax} Ingresa un espacio en el caracter numero 105`;
           
         }

    }else{
        contador.className = 'alert alert-success';
    }
});




const mensaje2 = document.getElementById('motivo');
const contador2 = document.getElementById('contador2');

mensaje2.addEventListener('input', function(e) {
    const target = e.target;
    const longitudMax = 210;
    const longitudAct = target.value.length;
    contador2.innerHTML = `${longitudAct}/${longitudMax}`;
    var mens2 = document.getElementById('motivo').value;

    if(mens2.length > 104){
         contador2.className = 'alert alert-danger';

         if(mens2.charAt(104) == " "){
            contador2.className = 'alert alert-success';
         }
         else{
            contador2.innerHTML = `${longitudAct}/${longitudMax} Ingresa un espacio en el caracter numero 105`;
           
         }

    }else{
        contador2.className = 'alert alert-success';
    }
});