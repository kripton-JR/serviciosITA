function maximo(campo, limite) {
    if (campo.value.length >= limite) {
        campo.value = campo.value.substring(0, limite);
    }
}