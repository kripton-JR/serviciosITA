<?php
$nombre = $_POST['nombre'];
$semestre = $_POST['semestre'];
$carrera = $_POST['carrera'];
$solicitud = $_POST['solicito'];
$motivo = ['motivo'];
$telefono = $_POST['telefono'];
$email = $_POST['email'];
$numero_de_control =$_POST['numerocontrol'];

$fechaactual = date("d M,Y");
$meses = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");

ob_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solicitud para el análisis|ITA</title>
</head>

<?php 
include '../css/bootstrap.php';
?>

<body style="font-size: 14px;">
    <!--Para la cabezera del pdf -->
    <header style="position: fixed;top: -20px; left: 0px;right: 0px;height: 50px;">
        <table style="table-layout: fixed; width: 100%;">
            <tbody>
                <tr>
                    <?php 
                        $ruta_logotecnm ='../imagenes/logostecnm/Logo_TecNM.png';
                        $ruta_logotecnmalt ='../imagenes/logostecnm/logo_tecnmalt.png';
                        $ruta_logolibreplastico = '../imagenes/logostecnm/libre-plastico.png';
                        $ruta_dragontecnm = '../imagenes/logostecnm/dragon_tecnm.png';
                        $ruta_iso9001 = '../imagenes/logostecnm/iso_9001.png';
                        //header
                        $imagenBase64_tecnm = "data:image/png;base64," . base64_encode(file_get_contents($ruta_logotecnm));
                        //footer
                        $imagenBase64_tecnmalt ="data:image/png;base64," . base64_encode(file_get_contents($ruta_logotecnmalt));
                        $imagenBase64_logo_libre_plastico ="data:image/png;base64,".base64_encode(file_get_contents($ruta_logolibreplastico));
                        $imagenBase64_dragon_tecnm = "data:image/png;base64," . base64_encode(file_get_contents($ruta_dragontecnm));
                        $imagenBase64_iso_9001 = "data:image/png;base64," .base64_encode(file_get_contents($ruta_iso9001));

                        ?>
                    <td style="width: 70%;"><img src="<?php echo $imagenBase64_tecnm ?>" class="img-fluid" /></td>
                    <td style="width: 30%;" class="text-end">
                    </td>
                </tr>
            </tbody>
        </table>
    </header>

    <br>
    <br>
    <br><br>
    <!--Para el tituto del pdf-->
    <div class="">
        <div class="row">
            <p style="font-size: 10px; position: fixed; left: 0px; right: 0px;height: 50px;"
                class="text-end text-muted">
                Instituto Tecnológico de altamira <br> Departamento de
                Servicios Escolares
            </p>
        </div>

        <br>
        <br>

        <div class="row">
            <p class="text-center text-muted">"2021:Año de la independencia"</p>
        </div>
        <br>
        <div class="row">
            <h6 class="text-center" style="font-weight: lighter;">SOLICITUD DE ESTUDIANTE PARA EL ANÁLISIS DEL COMITE
                ACADÉMICO</h6>
            <h6 class="text-center" style="font-weight: lighter;">INSTITUTO TECNOLÓGICO DE ALTAMIRA</h6>
        </div>
    </div>
    <br>
    <!--Para el parrafo 1 y 2-->
    <div style="margin-left: 4em;margin-right: 4em;">
        <div class="row">
            <p class="text-end">Fecha: <span
                    class="text-decoration-underline"><?php echo date('d').' '.$meses[date('n')-1].' '.date('Y'); ?></span>
            </p>
            <p class="text-end">Asunto: Expresar de manera breve el motivo de la solicitud</p>
        </div>

        <div class="row">
            <p class="text-start">
                <span class="text-decoration-underline">C. LIC. GWENDOLYNE CRUZ COVARRUBIAS </span><br>
                Jefa de la división de Estudios Pofesionales <br>
                Instituto Tecnológico de Altamira
            </p>
        </div>
    </div>
    <div style="margin-left: 4em;margin-right: 4em;">
        <p>
        <table style="table-layout: fixed; width: 100%;">
            <tbody>
                <tr>
                    <td style="width: 21%;">
                        El que se suscribe C:
                    </td>
                    <td style="border-bottom:0.1px solid #000; width: 69%; text-align: center;">
                        <?php echo $nombre ?>
                    </td>
                    <td style="width: 10%;">
                        estudiante
                    </td>
                </tr>
            </tbody>
        </table>

        <table style="table-layout: fixed; width: 100%;">
            <tbody>
                <tr>
                    <td style="width: 4%;">
                        del
                    </td>

                    <td style="border-bottom:0.1px solid #000; width: 6%; text-align: center;">
                        <?php echo $semestre ?>
                    </td>
                    <td style="width: 25%; text-align: center;">
                        semestre, de la carrera de
                    </td>
                    <td style="border-bottom:0.1px solid #000; width: 48%; text-align: center;">
                        <?php echo $carrera ?>
                    </td>
                    <td style="width: 17%;">
                        con el numero de
                    </td>
                </tr>
            </tbody>
        </table>

        <table style="table-layout: fixed; width: 100%;">
            <tbody>
                <tr>
                    <td style="width: 8%;">
                        control
                    </td>
                    <td style="border-bottom:0.1px solid #000; width: 60%; text-align: center;">
                        <?php echo $numero_de_control ?>
                    </td>
                    <td style="width: 32%;">
                        ,solicito de la manera mas atenta
                    </td>
                </tr>
            </tbody>
        </table>
        <table style="table-layout: fixed; width: 100%;">
            <tbody>
                <?php 
            $solicitolength = strlen($solicitud);
            switch ($solicitolength) {
                case $solicitolength < 105:
                    echo '
                <tr>
                    <td style="border-bottom:0.1px solid #000; width: 100%;">'.substr($solicitud,0,105).'</td>
                </tr>
                <br>
                <tr>
                    <td style="border-bottom:0.1px solid #000; width: 100%;"></td>
                </tr>
                    ';
                    break;
                case $solicitolength < 210:

                    echo '
                <tr>
                    <td style="border-bottom:0.1px solid #000; width: 100%;">'.substr($solicitud,0,105).'</td>
                </tr>
                
                <tr>
                    <td style="border-bottom:0.1px solid #000; width: 100%;">'.substr($solicitud,105,105).'</td>
                </tr>
                    ';
                    break;
            }
            
            ?>
            </tbody>
        </table>
        </p>
    </div>
    <br><br>
    <div style="margin-left: 4em;margin-right: 4em;">
        Por los siguientes motivos:
        <p>
        <table style="table-layout: fixed; width: 100%;">
            <tbody>
                <tr>
                    <td style="width: 21%;">Motivos académicos:</td>
                    <td style="border-bottom:0.1px solid #000;width: 79%;"></td>
                </tr>

            </tbody>
        </table>
        <br>
        <table style="table-layout: fixed; width: 100%;">
            <tbody>
                <tr>
                    <td style="border-bottom:0.1px solid #000; width: 100%;">

                    </td>
                </tr>
            </tbody>
        </table>
        </p>
    </div>

    <div style="margin-left: 4em;margin-right: 4em;">
        <p>
        <table style="table-layout: fixed; width: 100%;">
            <tbody>
                <tr>
                    <td style="width: 21%;">Motivos personales:</td>
                    <td style="border-bottom:0.1px solid #000;width: 79%;"></td>
                </tr>

            </tbody>
        </table>
        <br>
        <table style="table-layout: fixed; width: 100%;">
            <tbody>
                <tr>
                    <td style="border-bottom:0.1px solid #000; width: 100%;">

                    </td>
                </tr>
            </tbody>
        </table>
        </p>
    </div>

    <div style="margin-left: 4em;margin-right: 4em;">

        <p>
        <table style="table-layout: fixed; width: 100%;">
            <tbody>
                <tr>
                    <td style="width: 8%;">Otros:</td>
                    <td style="border-bottom:0.1px solid #000;width: 92%;"></td>
                </tr>

            </tbody>
        </table>
        <br>
        <table style="table-layout: fixed; width: 100%;">
            <tbody>
                <tr>
                    <td style="border-bottom:0.1px solid #000; width: 100%;">

                    </td>
                </tr>
            </tbody>
        </table>
        </p>
    </div>
    <br><br><br>
    <div style="margin-left: 4em;margin-right: 4em;">
        <table style="table-layout: fixed; width: 100%;">
            <tbody>
                <tr>
                    <td style="width: 30%;"></td>
                    <td style="width: 40%; text-align: center;">ATENTAMENTE <br> <br></td>
                    <td style="width: 30%;"></td>
                </tr>
                <br>
                <tr>
                    <td style="width: 30%;"></td>
                    <td style="width: 40%; border-bottom: 0.1px solid #000;text-align: center;"><?php echo $nombre ?>
                    </td>
                    <td style="width: 30%;"></td>
                </tr>
                <tr>
                    <td style="width: 30%;"></td>
                    <td style="width: 40%;font-style: italic;text-align: center;">NOMBRE Y FIRMA DEL ESTUDIANTE</td>
                    <td style="width: 30%;"></td>
                </tr>
            </tbody>
        </table>
    </div>
    <br>
    <div style="margin-left: 4em;margin-right: 4em;">
        <table style="table-layout: fixed; width: 100%">
            <tr>
                <td style="width: 5%;"></td>
                <td style="width: 10%;">Teléfono:</td>
                <td style="width: 35%;border-bottom:0.1px solid #000; text-align: center;"><?php echo $telefono ?></td>

                <td style="width: 10%;">Correo:</td>
                <td style="width: 35%;border-bottom:0.1px solid #000; text-align: center;"><?php echo $email ?></td>
                <td style="width: 5%;"></td>
            </tr>

        </table>
    </div>

    <br><br>
    <div style="margin-left: 4em;margin-right: 4em;">
        <p style="">
            c.c.p. Interesado
        </p>
    </div>

    <footer>
        <table
            style="margin-left: 4em;margin-right: 4em; position: fixed;bottom: 40px;left: -20px;right: 0px;height: 50px;">
            <tbody>
                <tr>

                    <td style="border-bottom: dotted 1px #000; width: 10.66%; height: 70px;">
                        <img src="<?php echo $imagenBase64_tecnmalt ?>" alt="" class="img-fluid"
                            style="height: 60px; margin-right: 10px;">
                    </td>

                    <td style="border-bottom: dotted 1px #000; width: 10.66%;">
                        <img src="<?php echo $imagenBase64_logo_libre_plastico ?>" alt="" class="img-fluid"
                            style="height: 60px; margin-right: 10px;">
                    </td>

                    <td style="border-bottom: dotted 1px #000; width: 10.66%;">
                        <img src="<?php echo $imagenBase64_iso_9001 ?>" alt="" class="img-fluid"
                            style="height: 60px; margin-right: 10px;">
                    </td>

                    <td
                        style="text-align: center; margin-right: 10px; font-size: 10px; border-bottom: dotted 1px #000;width: 48%;">
                        <p>
                            Carretera Tampico-Mante, km 24.5 C.P.89600, Altamira, Tam. <br>
                            Tels.(833) 2-64-05-45, 2-64-12-94 <br>
                            email:dir_italtamira@tecnm.mx, contacto.italtamira@gmail.com <br>
                            www.italtamira.edu.mx
                        </p>
                    </td>

                    <td style="width: 20%;">
                    </td>
                </tr>
            </tbody>
        </table>
    </footer>

    <div style="position: fixed;bottom: 80px;left: 550px;right: 0px;height: 50px;">
        <img src="<?php echo $imagenBase64_dragon_tecnm ?>" alt="" class="img-fluid" style="height: 150px;">
    </div>
 

</body>

</html>
<?php

$html = ob_get_clean();
require_once '../dompdf/autoload.inc.php';
use Dompdf\Dompdf;
$dompdf = new Dompdf();

$options = $dompdf->getOptions();
$options->set(array('isRemoteEnable'=> true));
$dompdf->setOptions($options);

$dompdf->loadHtml($html);
$dompdf->setPaper('A4',"portrait");
$dompdf->render();
$dompdf->stream('Solicitud().pdf', array('Attachment'=>false))

?>