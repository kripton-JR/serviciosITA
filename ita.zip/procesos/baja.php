<?php
$baja= $_POST['tipobaja'];
$motivobaja = $_POST['motivobaja'];
$motivo = $_POST['motivo'];
$motivolengt = strlen($motivo);
$semestre =$_POST['semestre'];
$grupo = $_POST['grupo'];
$numcontrol = $_POST['numerocontrol'];
$carrera = $_POST['carrera'];
$nombre = $_POST['nombre'];
$fechaactual = date("d M,Y");
$meses = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");

if($baja == "" || $motivobaja=="" || $motivo == "" || $semestre == "" 
   || $grupo == "" || $grupo == "" || $numcontrol == "" || $carrera == "" || $nombre == ""){
    $bandera = true;
    header("Location: ../bajas.php?bandera=".$bandera);
   }else{
    $bandera = false;
   }
ob_start();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solicitud de baja[<?php echo $numcontrol?>]</title>
</head>

<?php 
include '../css/bootstrap.php';
?>

<body style="font-size: 14px;font-family:'Calibri (Body)';margin-left: 4em;margin-right: 4em; ">

    <div class="">
        <div class="row">
            <p>
                <span class="fw-normal fw-lighter">SOLICITUD DE BAJA</span> <span
                    class="mx-5 fw-normal fw-lighter">TEMPORAL (<?php if($baja==1){echo'X';} ?>) DEFINITIVA
                    (<?php if($baja==2){echo'X';} ?>)</span>
            </p>
            <br>
        </div>
        <div class="row">
            <p class="text-end">
                Altamira. Tam., a <span class="fw-lighter"
                    style="border-bottom:0.1px solid #000;"><?php echo date('d').' '.$meses[date('n')-1].' '.date('Y'); ?></span>
            </p>
        </div>
        <div class="row">
            <p>
                <span class="fw-normal fw-bold" style="font-size: 14px;font-family:'Calibri (Body)';">
                    ING. MIGUEL ANGEL VILLAR MORALES
                </span> <br>
                DIRECTOR <br>
                <span class="font-monospace" style="letter-spacing: 2px;">PRESENTE</span>
            </p>
        </div>
        <div class="row">
            <p class="text-end fw-normal fw-lighter">
                AT´N: LIC. GWENDOLYNE CRUZ COVARRUBIAS <br>
                JEFA DEL DEPTO DIV. DE EST. PROFESIONALES
            </p>
        </div>
        <br><br>
        <div class="row">
            <p class="text-start mx-0">A trave del presente, solicito mi
                <span class="fw-bold" style="border-bottom:0.1px solid #000;">BAJA</span>
                del plantel, por los siguientes motivos:
            </p>
        </div>
<!------------------------------------------------------------------------------------------------------------------------------------------>
        <div class="row">
            <p>
            MOTIVOS ACADEMICOS
            <?php 
            if($motivobaja == 1){
              
                switch ($motivolengt) {
                    case $motivolengt < 93:
                        echo '<table>
                        <tbody>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;">'.substr($motivo,0,93).'</td>
                            </tr>
                            <br>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;"></td>
                            </tr>
                           <br>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;"></td>
                            </tr>
                           <br>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;"></td>
                            </tr>
                        </tbody>
                    </table>';
                        break;
                    
                    case $motivolengt < 186:
                        echo '<table>
                        <tbody>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;">'.substr($motivo,0,93).'</td>
                            </tr>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;">'.substr($motivo,93,93).'</td>
                            </tr>
                           <br>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;"></td>
                            </tr>
                           <br>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;"></td>
                            </tr>
                        </tbody>
                    </table>';
                        break;

                        case $motivolengt < 279:
                            echo '<table>
                        <tbody>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;">'.substr($motivo,0,93).'</td>
                            </tr>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;">'.substr($motivo,93,93).'</td>
                            </tr>
                          
                            <tr>
                                <td style="border-bottom:0.1px solid #000;">'.substr($motivo,186,93).'</td>
                            </tr>
                           <br>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;"></td>
                            </tr>
                        </tbody>
                    </table>';
                            break;

                        case $motivolengt > 279:
                            echo '<table>
                            <tbody>
                                <tr>
                                    <td style="border-bottom:0.1px solid #000;">'.substr($motivo,0,93).'</td>
                                </tr>
                                <tr>
                                    <td style="border-bottom:0.1px solid #000;">'.substr($motivo,93,93).'</td>
                                </tr>
                               
                                <tr>
                                    <td style="border-bottom:0.1px solid #000;">'.substr($motivo,186,93).'</td>
                                </tr>
                               
                                <tr>
                                    <td style="border-bottom:0.1px solid #000;">'.substr($motivo,279,93).'</td>
                                </tr>
                            </tbody>
                        </table>';
                            break;
                }

            }
            else{

                echo '<table>
                <tbody>
                    <tr>
                        <td style="border-bottom:0.1px solid #000;"></td>
                    </tr>
                    <br>
                    <tr>
                        <td style="border-bottom:0.1px solid #000;"></td>
                    </tr>
                   <br>
                    <tr>
                        <td style="border-bottom:0.1px solid #000;"></td>
                    </tr>
                   <br>
                    <tr>
                        <td style="border-bottom:0.1px solid #000;"></td>
                    </tr>
                </tbody>
            </table>';

            }
            ?>
            </p>

        </div>
        <br>
<!------------------------------------------------------------------------------------------------------------------------------------------>
        <div class="row">
            <p> MOTIVOS PERSONALES
            <?php 
            if($motivobaja == 2){
              
                switch ($motivolengt) {
                    case $motivolengt < 93:
                        echo '<table>
                        <tbody>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;">'.substr($motivo,0,93).'</td>
                            </tr>
                            <br>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;"></td>
                            </tr>
                           <br>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;"></td>
                            </tr>
                           <br>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;"></td>
                            </tr>
                        </tbody>
                    </table>';
                        break;
                    
                    case $motivolengt < 186:
                        echo '<table>
                        <tbody>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;">'.substr($motivo,0,93).'</td>
                            </tr>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;">'.substr($motivo,93,93).'</td>
                            </tr>
                           <br>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;"></td>
                            </tr>
                           <br>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;"></td>
                            </tr>
                        </tbody>
                    </table>';
                        break;

                        case $motivolengt < 279:
                            echo '<table>
                        <tbody>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;">'.substr($motivo,0,93).'</td>
                            </tr>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;">'.substr($motivo,93,93).'</td>
                            </tr>
                          
                            <tr>
                                <td style="border-bottom:0.1px solid #000;">'.substr($motivo,186,93).'</td>
                            </tr>
                           <br>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;"></td>
                            </tr>
                        </tbody>
                    </table>';
                            break;

                        case $motivolengt > 279:
                            echo '<table>
                            <tbody>
                                <tr>
                                    <td style="border-bottom:0.1px solid #000;">'.substr($motivo,0,93).'</td>
                                </tr>
                                <tr>
                                    <td style="border-bottom:0.1px solid #000;">'.substr($motivo,93,93).'</td>
                                </tr>
                               
                                <tr>
                                    <td style="border-bottom:0.1px solid #000;">'.substr($motivo,186,93).'</td>
                                </tr>
                               
                                <tr>
                                    <td style="border-bottom:0.1px solid #000;">'.substr($motivo,279,93).'</td>
                                </tr>
                            </tbody>
                        </table>';
                            break;
                }

            }
            else{

                echo '<table>
                <tbody>
                    <tr>
                        <td style="border-bottom:0.1px solid #000;"></td>
                    </tr>
                    <br>
                    <tr>
                        <td style="border-bottom:0.1px solid #000;"></td>
                    </tr>
                   <br>
                    <tr>
                        <td style="border-bottom:0.1px solid #000;"></td>
                    </tr>
                   <br>
                    <tr>
                        <td style="border-bottom:0.1px solid #000;"></td>
                    </tr>
                </tbody>
            </table>';

            }
            ?>
            </p>
        </div>
<!------------------------------------------------------------------------------------------------------------------------------------------>
<br>
        <div class="row">
            <p>OTROS(especifique)
            <?php 
            if($motivobaja == 3){
              
                switch ($motivolengt) {
                    case $motivolengt < 93:
                        echo '<table>
                        <tbody>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;">'.substr($motivo,0,93).'</td>
                            </tr>
                            <br>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;"></td>
                            </tr>
                           <br>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;"></td>
                            </tr>
                           <br>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;"></td>
                            </tr>
                        </tbody>
                    </table>';
                        break;
                    
                    case $motivolengt < 186:
                        echo '<table>
                        <tbody>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;">'.substr($motivo,0,93).'</td>
                            </tr>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;">'.substr($motivo,93,93).'</td>
                            </tr>
                           <br>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;"></td>
                            </tr>
                           <br>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;"></td>
                            </tr>
                        </tbody>
                    </table>';
                        break;

                        case $motivolengt < 279:
                            echo '<table>
                        <tbody>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;">'.substr($motivo,0,93).'</td>
                            </tr>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;">'.substr($motivo,93,93).'</td>
                            </tr>
                          
                            <tr>
                                <td style="border-bottom:0.1px solid #000;">'.substr($motivo,186,93).'</td>
                            </tr>
                           <br>
                            <tr>
                                <td style="border-bottom:0.1px solid #000;"></td>
                            </tr>
                        </tbody>
                    </table>';
                            break;

                        case $motivolengt > 279:
                            echo '<table>
                            <tbody>
                                <tr>
                                    <td style="border-bottom:0.1px solid #000;">'.substr($motivo,0,93).'</td>
                                </tr>
                                <tr>
                                    <td style="border-bottom:0.1px solid #000;">'.substr($motivo,93,93).'</td>
                                </tr>
                               
                                <tr>
                                    <td style="border-bottom:0.1px solid #000;">'.substr($motivo,186,93).'</td>
                                </tr>
                               
                                <tr>
                                    <td style="border-bottom:0.1px solid #000;">'.substr($motivo,279,93).'</td>
                                </tr>
                            </tbody>
                        </table>';
                            break;
                }

            }
            else{

                echo '<table>
                <tbody>
                    <tr>
                        <td style="border-bottom:0.1px solid #000;"></td>
                    </tr>
                    <br>
                    <tr>
                        <td style="border-bottom:0.1px solid #000;"></td>
                    </tr>
                   <br>
                    <tr>
                        <td style="border-bottom:0.1px solid #000;"></td>
                    </tr>
                   <br>
                    <tr>
                        <td style="border-bottom:0.1px solid #000;"></td>
                    </tr>
                </tbody>
            </table>';

            }
            ?>
            </p>
        </div>              
        <br>
        <div class="row">
           <table style="table-layout: fixed; width: 100%;">
            <tbody>
               <tr>
                <td style="width:21%;">Semestre cursado:</td>
                <td style="border-bottom:0.1px solid #000; width:10%; text-align: center;"><?php echo $semestre ?></td>
                <td style="width:8%;">Grupo:</td>
                <td style="border-bottom:0.1px solid #000; width:10%; text-align: center;"><?php echo $grupo ?></td>
                <td style="width:18%;">No. De control:</td>
                <td style="border-bottom:0.1px solid #000; width:15%; text-align: center;"><?php echo $numcontrol ?></td>
                <td style="width: auto;"></td>   
            </tr>
            </tbody>
           </table>
        </div>
        <br>
        <div class="row">
           <table style="table-layout: fixed; width: 100%;">
            <tbody>
                <tr>
                    <td style="width: 10%;">Carrera:</td>
                    <td style="width: 50%; border-bottom:0.1px solid #000;"><?php echo $carrera?></td>
                    <td style="width: 40%;"></td>
                </tr>
            </tbody>
           </table>
        </div>
        <br>
        <div class="row">
            <p>Agradeciendo su atencíon.</p>
        </div>
        <br>
        <div class="row">
            <table style="table-layout: fixed; width: 100%;">
                <tbody>
                    <tr>
                        <td style="width:25%;"> </td>
                        <td class="font-monospace text-center" style="letter-spacing: 2px; width: 50%;">ATENTAMENTE</td>
                        <td style="width:25%;"> </td>
                    </tr>
                    <br>
                    <br>
                    <tr>
                        <td> </td>
                        <td class="text-center" style="border-bottom:0.1px solid #000;"><?php echo $nombre?></td>
                        <td> </td>
                    </tr>
                    <tr>
                        <td> </td>
                        <td class="text-center">Nombre y firma del interesado</td>
                        <td> </td>
                    </tr>
                    <br><br>
                    <tr>
                        <td> </td>
                        <td class="text-center">Vo.Bo.</td>
                        <td> </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <br><br><br>
        <div class="row">
            <table style="table-layout: fixed; width: 100%;">
                <tbody>
                    <tr>
                        <td class="text-center" style="width: 40%; border-bottom:0.1px solid #000;"></td>
                        <td style="width: 20%;"></td>
                        <td class="text-center" style="width: 40%; border-bottom:0.1px solid #000;"></td>
                    </tr>
                    <tr>

                        <td class="text-center">Firma del tutor</td>
                        <td> </td>
                        <td class="text-center">Firma del Coordinador de tutorias</td>
                    </tr>

                </tbody>
            </table>
        </div>
        <br><br>
        <div class="row">
            <p class="fw-bold">c.c.p.-Depto. De Servicios Escolares</p>
        </div>

    </div>

</body>

</html>
<?php

$html = ob_get_clean();
require_once '../dompdf/autoload.inc.php';
use Dompdf\Dompdf;
$dompdf = new Dompdf();
$options = $dompdf->getOptions();
$options->set(array('isRemoteEnable' => true));
$dompdf->setOptions($options);
$dompdf->setBasePath('');
$dompdf->loadHtml($html);
$dompdf->setPaper('A4',"portrait");
//$dompdf->set_paper("A4", "portrait");
$dompdf->render();
$dompdf->stream('Reporte_Baja('.$numcontrol.').pdf', array('Attachment'=>false))

?>