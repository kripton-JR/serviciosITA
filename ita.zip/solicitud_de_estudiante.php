<?php

include './templates/navbar.php';
?>


<div class="container">
    <h2 class="text-center mt-3" style="font-size: 40px;">SOLICITUD PARA EL ANÁLISIS DEL COMITÉ ACADÉMICO
        INSTITUTO TECNOLOGICO DE ALTAMIRA
    </h2>
    <div class="solicitud container mt-5 justify-content-center">
        <?php
        /*
            if ($banera == true) {
                echo '<div class="alert alert-danger" role="alert">
            Ingresa informacion valida
            </div>';
            }
        */
        ?>
          
        <form action="procesos\solesancoac.php" method="post" target="_blank">
            <div class="row">
                <div class="col-sm-12 col-md-6">
                    <div class="row">

                        <div>
                            <label for="motivosolicitud" class="form-label">Motivo de la solicitud</label>
                            <select class="form-select" aria-label="Default select example" name="motivosolicitud">
                                <option selected>Seleccione el motivo de la solicitud</option>
                                <option value="1">Académicos</option>
                                <option value="2">Personales</option>
                                <option value="3">Otros</option>
                            </select>
                        </div>

                        <div>
                            <label for="solicito" class="form-label">Solicito de la manera manera mas
                                atenta:</label><br>
                            <textarea rows="5" name="solicito" id="solicito" class="form-control" onKeyUp="maximo(this,210);"
                                onKeyDown="maximo(this,210);"
                                placeholder="Que se realize un seguimiento de mi solicitud."></textarea>
        
                            <div id="contador" class="alert alert-success" role="alert">0/210</div>
                            
                        </div>
                    </div>

                    <div>
                        <label for="motivo" class="form-label">Describa de manera breve su motivo:</label><br>
                        <textarea rows="5" name="motivo" class="form-control" id="motivo" onKeyUp="maximo(this,210);"
                            onKeyDown="maximo(this,210);"
                            placeholder="Nesesito se revise,para poder continuar con el proceso."></textarea>
                            <div id="contador2" class="alert alert-success" role="alert">0/210</div>
                    </div>

                    <div class="row">
                        <div class="col-sm-12 col-md-4">
                            <label for="semestre" class="form-label">Semestre</label>
                            <select class="form-select" aria-label="Default select example" name="semestre">
                                <option selected>Seleccione</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                                <option value="9">9</option>
                                <option value="10">10</option>
                                <option value="11">11</option>
                                <option value="12">12</option>
                            </select>
                        </div>
                        <div class="col-sm-12 col-md-4">
                            <label for="grupo" class="form-label">Grupo</label>
                            <select class="form-select" aria-label="Default select example" name="grupo">
                                <option selected>Grupo</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        </div>
                        <div class="col-sm-12 col-md-4">
                            <label for="" class="form-label">Numero de control</label>
                            <input type="number" class="form-control" name="numerocontrol" id="">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12 col-md-6">
                            <label for="telefono" class="form-label">Telefono</label>
                            <input type="number" name="telefono" id="" class="form-control">
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <label for="correo" class="form-label">Correo:</label>
                            <input type="email" name="email" class="form-control" id="">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-12 col-md-12">
                            <label for="carrera" class="form-label">Carrera</label>
                            <select class="form-select" aria-label="Default select example" name="carrera">
                                <option selected>Carrera</option>
                                <option value="Ingenieria en sistemas computacionales">Ingenieria en sistemas
                                    computacionales</option>
                                <option value="Ingenieria en logistica">Ingenieria en logistica</option>
                                <option value="Ingenieria en agronomia">Ingenieria en agronomia</option>
                                <option value="Lic. Biologia">Lic. Biologia</option>
                                <option value="Lic. Administracion de empresas">Lic. Administracion de empresas</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12 col-md-12">
                            <label for="nombre" class="form-label">Nombre completo</label>
                            <input type="text" name="nombre" id="" class="form-control">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-12 col-md-12 d-grid d-gap-2">
                            <input type="submit" value="Solicitar PDF" class="btn btn-primary">
                        </div>
                    </div>

                </div>

                <div class="col-sm-12 col-md-6">
                    <img src="imagenes\imagenesSVG\Full Inbox _Two Color (1).svg"
                        alt="Estudiantes desarrollando un sistema" class="img-fluid" style="width: 50em;">
                </div>

            </div>
        </form>
    </div>
</div>
<script src="js/camposmaximo.js"></script>
<script src="js/contador.js"></script>

<?php
include './templates/footer.php';
?>