<?php

include 'templates\navbar.php';
?>


<div class="buttons">
    <div class="row">
        <div class="col-md-4 col-sm-12">
            <a href="" class="btn btn-success"></a>
        </div>

        <div class="col-md-4 col-sm-12">

        </div>

        <div class="col-md-4 col-sm-12">

        </div>
    </div>
</div>



<?php

include 'templates\footer.php';
?>